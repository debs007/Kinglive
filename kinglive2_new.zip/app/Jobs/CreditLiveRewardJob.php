<?php

namespace App\Jobs;

use App\Models\LiveReward;
use App\Models\Room;
use App\Models\User;
use App\Models\CoinTransaction;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

/**
 * Runs every minute via scheduler.
 * Finds live rooms that have been running >= 40 minutes,
 * credits 5000 diamonds to the host — once per user per day.
 * Uses live_rewards table as the source of truth (not Redis).
 */
class CreditLiveRewardJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private const REWARD_AMOUNT   = 5000;
    private const MIN_DURATION    = 40; // minutes

    public function handle(): void
    {
        $today = now()->toDateString();

        // Find all rooms that:
        // 1. Are live OR ended (host may have ended before job ran)
        // 2. NOT ended by admin
        // 3. Duration >= 40 minutes
        // 4. Host has NOT already received reward today
        $eligibleRooms = Room::whereIn('status', ['live', 'ended'])
            // admin force-ended rooms won't reach 40 mins so naturally excluded
            ->whereNotNull('started_at')
            ->where(function ($q) {
                // For live rooms: use current time to calculate duration
                // For ended rooms: use ended_at to calculate duration
                $q->where(function ($q2) {
                    $q2->where('status', 'live')
                       ->whereRaw('TIMESTAMPDIFF(MINUTE, started_at, NOW()) >= ?', [self::MIN_DURATION]);
                })->orWhere(function ($q2) {
                    $q2->where('status', 'ended')
                       ->whereNotNull('ended_at')
                       ->whereRaw('TIMESTAMPDIFF(MINUTE, started_at, ended_at) >= ?', [self::MIN_DURATION]);
                });
            })
            ->whereNotIn('host_user_id',
                LiveReward::where('reward_date', $today)
                    ->pluck('user_id')
            )
            // Only look at today's rooms — no point rewarding old ended rooms
            ->whereDate('started_at', $today)
            ->get(['id', 'host_user_id', 'started_at', 'ended_at', 'status']);

        foreach ($eligibleRooms as $room) {
            $this->creditReward($room, $today);
        }
    }

    private function creditReward(Room $room, string $today): void
    {
        try {
            DB::transaction(function () use ($room, $today) {
                // Insert into live_rewards — unique(user_id, reward_date)
                // If another process already inserted, this will throw and roll back
                LiveReward::create([
                    'user_id'     => $room->host_user_id,
                    'reward_date' => $today,
                    'room_id'     => $room->id,
                    'amount'      => self::REWARD_AMOUNT,
                    'credited_at' => now(),
                ]);

                // Credit diamonds
                User::where('id', $room->host_user_id)
                    ->increment('diamond_balance', self::REWARD_AMOUNT);

                // Record transaction
                $user = User::find($room->host_user_id);
                CoinTransaction::create([
                    'user_id'       => $room->host_user_id,
                    'type'          => 'live_reward',
                    'amount'        => self::REWARD_AMOUNT,
                    'balance_after' => $user?->diamond_balance ?? 0,
                    'reference'     => "live_reward:room:{$room->id}:{$today}",
                ]);

                Log::info("LiveReward credited: user={$room->host_user_id} room={$room->id} date={$today}");
            });
        } catch (\Illuminate\Database\UniqueConstraintViolationException $e) {
            // Already credited today — race condition safely handled by DB unique constraint
        } catch (\Exception $e) {
            Log::error("LiveReward failed: user={$room->host_user_id} error={$e->getMessage()}");
        }
    }
}