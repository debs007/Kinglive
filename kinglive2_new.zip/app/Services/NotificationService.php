<?php

namespace App\Services;

use App\Models\User;
use Google\Auth\Credentials\ServiceAccountCredentials;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class NotificationService
{
    private string $projectId;
    private string $credentialsPath;

    public function __construct()
    {
        $this->projectId       = config('services.fcm.project_id', '');
        $this->credentialsPath = config('services.fcm.credentials_path',
            storage_path('app/firebase-credentials.json'));
    }

    // ── Get OAuth2 access token from service account ──────────────────────────

    private function getAccessToken(): string
    {
        try {
            $credentials = new ServiceAccountCredentials(
                'https://www.googleapis.com/auth/firebase.messaging',
                $this->credentialsPath
            );
            $token = $credentials->fetchAuthToken();
            return $token['access_token'] ?? '';
        } catch (\Throwable $e) {
            Log::error('FCM getAccessToken error: ' . $e->getMessage());
            return '';
        }
    }

    // ── Send to single user ───────────────────────────────────────────────────

    public function sendToUser(int $userId, string $title, string $body, array $data = []): bool
    {
        $user = User::find($userId);
        if (! $user || ! $user->device_token) {
            return false;
        }
        return $this->sendFcm([$user->device_token], $title, $body, $data);
    }

    // ── Notify followers when host goes live ──────────────────────────────────

    public function notifyFollowersLive(int $hostId, string $roomId, string $title): void
    {
        $host = User::with('followers:id,device_token')->find($hostId);
        if (! $host) return;

        $tokens = $host->followers
            ->whereNotNull('device_token')
            ->pluck('device_token')
            ->filter()
            ->values()
            ->toArray();

        if (empty($tokens)) return;

        $this->sendFcm(
            $tokens,
            "{$host->display_name ?? $host->username} is LIVE! 🔴",
            $title ?: 'Join the stream now',
            ['type' => 'host_live', 'room_id' => $roomId]
        );
    }

    // ── Withdrawal status ─────────────────────────────────────────────────────

    public function notifyWithdrawalStatus(int $userId, string $status): void
    {
        $messages = [
            'approved' => ['title' => 'Withdrawal Approved ✅', 'body' => 'Your withdrawal has been approved.'],
            'rejected' => ['title' => 'Withdrawal Rejected ❌', 'body' => 'Your withdrawal was rejected.'],
        ];
        if (! isset($messages[$status])) return;

        $this->sendToUser($userId, $messages[$status]['title'],
            $messages[$status]['body'],
            ['type' => 'withdrawal_update', 'status' => $status]);
    }

    // ── Core FCM v1 sender ────────────────────────────────────────────────────

    private function sendFcm(array $tokens, string $title, string $body, array $data = []): bool
    {
        if (empty($this->projectId) || empty($tokens)) {
            Log::warning('FCM: missing project_id or no tokens');
            return false;
        }

        $accessToken = $this->getAccessToken();
        if (empty($accessToken)) {
            Log::error('FCM: could not get access token');
            return false;
        }

        $url     = "https://fcm.googleapis.com/v1/projects/{$this->projectId}/messages:send";
        $success = true;

        // FCM v1 sends one message per token
        foreach ($tokens as $token) {
            try {
                $response = Http::withHeaders([
                    'Authorization' => "Bearer {$accessToken}",
                    'Content-Type'  => 'application/json',
                ])->post($url, [
                    'message' => [
                        'token'        => $token,
                        'notification' => [
                            'title' => $title,
                            'body'  => $body,
                        ],
                        'android' => [
                            'priority'     => 'high',
                            'notification' => [
                                'sound'        => 'default',
                                'click_action' => 'FLUTTER_NOTIFICATION_CLICK',
                            ],
                        ],
                        'apns' => [
                            'payload' => [
                                'aps' => ['sound' => 'default', 'badge' => 1],
                            ],
                        ],
                        // All data values must be strings for FCM v1
                        'data' => array_map('strval', $data),
                    ],
                ]);

                if (! $response->successful()) {
                    Log::warning('FCM v1 failed', [
                        'status'   => $response->status(),
                        'response' => $response->body(),
                    ]);
                    $success = false;
                }
            } catch (\Throwable $e) {
                Log::error('FCM send exception: ' . $e->getMessage());
                $success = false;
            }
        }

        return $success;
    }
}